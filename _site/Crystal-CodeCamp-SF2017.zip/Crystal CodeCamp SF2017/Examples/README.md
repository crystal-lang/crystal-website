== Crystal CodeCamp SF2017 Examples ==

Some of these examples require a big json file located at https://github.com/zemirco/sf-city-lots-json. Download it and place it in this directory before running the examples.

The GitHub and Twitter examples also requires tokens and OAuth secrets. Make sure to edit those files and fill with your authentication keys before running those examples.
