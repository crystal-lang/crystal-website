#include <stdio.h>
#include <lua.h>
#include <lauxlib.h>

int main(void)
{
	// create a Lua state
	lua_State *L = luaL_newstate();

	// load and execute a string
	if (luaL_dostring(L, "function addition(x,y) return x+y end")) {
    printf("Failed to execute string\n");
		lua_close(L);
		return -1;
	}

	// push value of global "addition" (the function defined above)
	// to the stack, followed by integers 5 and 3
	lua_getglobal(L, "addition");
	lua_pushinteger(L, 5);
	lua_pushinteger(L, 3);
	lua_call(L, 2, 1); // call a function with two arguments and one return value
	printf("Result: %ld\n", lua_tointeger(L, -1)); // print integer value of item at stack top

  // close Lua state
	lua_close(L);

	return 0;
}

