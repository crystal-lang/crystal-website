#include <stdio.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

typedef struct {
  const char *name;
  double balance;
} Account;

static Account *get_account(lua_State *L, int arg)
{
  return (Account*)luaL_checkudata(L, arg, "Account");
}

static int account_name(lua_State *L)
{
  Account *acct = get_account(L, 1);
  lua_pushstring(L, acct->name);
  return 1;
}

static int account_balance(lua_State *L)
{
  Account *acct = get_account(L, 1);
  lua_pushnumber(L, acct->balance);
  return 1;
}

static int account_deposit(lua_State *L)
{
  Account *acct = get_account(L, 1);
  lua_Number amount = luaL_checknumber(L, 2);
  acct->balance += amount;
  lua_pushnumber(L, acct->balance);
  return 1;
}

static int account_withdraw(lua_State *L)
{
  Account *acct = get_account(L, 1);
  lua_Number amount = luaL_checknumber(L, 2);
  acct->balance -= amount;
  lua_pushnumber(L, acct->balance);
  return 1;
}

static const luaL_Reg methods[] = {
  {"name", &account_name},
  {"balance", &account_balance},
  {"deposit", &account_deposit},
  {"withdraw", &account_withdraw},
  {NULL, NULL}
};

static void register_account(lua_State *L)
{
  luaL_newmetatable(L, "Account");
  luaL_setfuncs(L, methods, 0);

  lua_pushvalue(L, -1);
  lua_setfield(L, -1, "__index");

  // optional
  lua_setglobal(L, "Account");
}

int main(void)
{
  Account my_account = {"My Account", 100};

	// create a Lua state
	lua_State *L = luaL_newstate();

  // for print()
  luaL_openlibs(L);

  // register Account metatable
  register_account(L);

  // push my_account to Lua
  lua_pushlightuserdata(L, &my_account);

  // retrieve metatable and set it to the account
  luaL_getmetatable(L, "Account");
  lua_setmetatable(L, -2);

  // save the account in globals
  lua_setglobal(L, "my_account");

	// load and execute a string
	luaL_dofile(L, "account.lua");

  // close Lua state
	lua_close(L);

	return 0;
}
