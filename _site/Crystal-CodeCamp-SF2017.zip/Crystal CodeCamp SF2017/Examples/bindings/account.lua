print("my_account:", my_account)
print("Account name:", my_account:name())
print("Starting balance:", my_account:balance())
print("Deposit $50:", my_account:deposit(50))
print("Withdraw $100:", my_account:withdraw(100))
print("Final balance:", my_account:balance())

