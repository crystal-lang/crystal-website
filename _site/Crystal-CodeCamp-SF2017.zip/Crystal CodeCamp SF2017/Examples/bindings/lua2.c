#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

int main(void)
{
	// create a Lua state
	lua_State *L = luaL_newstate();

  // open standard libraries (for I/O)
  luaL_openlibs(L);

	// load and execute a file
	int result = luaL_dofile(L, "sample.lua");
  printf("luaL_dofile : %d\n", result);

  // close Lua state
	lua_close(L);

	return 0;
}
