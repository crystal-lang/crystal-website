#include <stdio.h>
#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

static int addition(lua_State *L)
{
  // retrieve parameters (warning: types not checked!)
  lua_Integer x = lua_tointeger(L, 1);
  lua_Integer y = lua_tointeger(L, 2);

  // push result
  lua_pushinteger(L, x+y);

  // return number of result values
  return 1;
}

int main(void)
{
	// create a Lua state
	lua_State *L = luaL_newstate();

  // for print()
  luaL_openlibs(L);

  // register C function
  lua_register(L, "addition", &addition);

	// load and execute a string
	if (luaL_dostring(L, "x = addition(3,5); print(x)")) {
    printf("Failed to execute string\n");
		lua_close(L);
		return -1;
	}

  // close Lua state
	lua_close(L);

	return 0;
}

