#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

int main(void)
{
	// create a Lua state
	lua_State *L = luaL_newstate();

  // open standard libraries (for I/O)
  luaL_openlibs(L);

	// load and execute a string
	int result = luaL_dostring(L, "print('hello world')");
  printf("luaL_dostring : %d\n", result);

  // close Lua state
	lua_close(L);

	return 0;
}
